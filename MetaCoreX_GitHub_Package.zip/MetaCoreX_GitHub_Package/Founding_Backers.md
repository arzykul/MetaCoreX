# Founding Backers – The Ones Who Believed First

| Name / Fund           | Contribution ($) | Message                      |
|-----------------------|------------------|-------------------------------|
| TBD                   | $20,000          | "We believed in MetaCoreX."  |
