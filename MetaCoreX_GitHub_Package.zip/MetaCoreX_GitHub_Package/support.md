# Support MetaCoreX

## Help us build the core of digital civilization.

MetaCoreX is for the 1 billion people already working online. If you believe in this mission, support it as a Founding Backer.

Your name, message, and contribution will be permanently honored.
